// init function runs when page has fully loaded
function init() {
	// code to run
}

window.onload = init;
