// define global variables
var dragging;           // the list item being dragged
var dir;                     // the direction (up or down) the drag is going in

function init() {
          var li = document.getElementsByTagName("li");
          // loop through all the list items and make them draggable and set the event handler functions
          for ( var i = 0; i < li.length; i++ )
          {
                    li[i].draggable = true;
                    li[i].ondragover = dragOverHandler;
                    li[i].ondragstart = dragStartHandler;
                    li[i].ondragend = dragEndHandler;
          }
}
function dragStartHandler(e) {
          dragging = e.target;
          e.dataTransfer.setData('text/plain' , null);
          dragging.style.opacity = "0.5";
}
function dragOverHandler(e) {	
          // make sure the item being dragged isn�t the same as the one we�re dragging over
          // and make sure it hasn�t been removed from the page
          if (dragging != e.target && dragging.parentNode != null) 
          {
                    // determine whether the drag in going up or down
                    if ( e.target.previousElementSibling == dragging ) dir = "down";
                    else dir = "up";
                    
                    // remove the item being dragged from the page
                    dragging.parentNode.removeChild(dragging);	

                    // add the item being dragged back in above or below the item being dragged over
                    if (dir == "down") dragging = e.target.parentNode.appendChild(dragging , e.target);
                    else if (dir == "up") dragging = e.target.parentNode.insertBefore(dragging , e.target);
           }
           // prevent the default behavior
           if (e.preventDefault) e.preventDefault();
           return false;
} 
function dragEndHandler(e) {
          dragging.style.opacity = "1.0";
}

window.onload = init;
