var video;
var control_button;
var control_label;
var control_graphic;

function init()
{
	video = document.getElementById("my_video");
	control_button = document.getElementById("control_button");
	control_label = document.getElementById("control_label");
	control_graphic = document.getElementById("control_graphic");

	control_button.onclick = playVideo;		
}

function playVideo()
{
	control_graphic.className = "pause";

	control_button.onclick = pauseVideo;
	control_button.title = "Pause";
	control_label.textContent = "Pause";

	video.play();

	return false;
}

function pauseVideo()
{
	control_graphic.className = "play";

	control_button.onclick = playVideo;
	control_button.title = "Play";
	control_label.textContent = "Play";

	video.pause();

	return false;
}

window.onload = init;
