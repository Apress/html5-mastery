// declare global variables
var canvas;
var context; 

// initialize animation
function init() {
	// set variable values
	canvas = document.getElementById( "canvas" );
	context = canvas.getContext("2d");
           
	context.save();
	context.strokeStyle = "#ff0000";
	context.strokeRect(0,0,100,100);
	context.restore();
	
	context.save();
	context.strokeStyle = "#00ff00";
	context.strokeRect(50,50,100,100);
	context.restore();
	
	context.save();
	context.strokeStyle = "#0000ff";
	context.strokeRect(100,100,100,100);
	context.restore();
	
	// Rectangular outline will be default black, because original style settings were restored context.strokeRect(0,0,200,200);
	context.strokeRect(0,0,200,200);
}
window.onload = init;
