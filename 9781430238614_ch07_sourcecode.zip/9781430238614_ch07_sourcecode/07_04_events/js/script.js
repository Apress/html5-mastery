function windowClickHandler() { 
            alert( "Window was clicked" );   // pops up an alert box
}
window.onclick = windowClickHandler;


function windowMouseDownHandler(e) { 
            console.log(e);                                                                            // logs the event object
            console.log("Mouse is at: " + e.pageX + ", " + e.pageY);          // log the mouse location
}
window.onmousedown = windowMouseDownHandler;
