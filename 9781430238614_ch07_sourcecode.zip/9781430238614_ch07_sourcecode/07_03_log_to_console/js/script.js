// init function runs when page has fully loaded
function init() {
	console.log("message");    // log a message to the JavaScript console
	console.log(window);    // log the window object to the JavaScript console.
	console.log(window.constructor.prototype);    // log the window object�s prototype.
}

window.onload = init;
