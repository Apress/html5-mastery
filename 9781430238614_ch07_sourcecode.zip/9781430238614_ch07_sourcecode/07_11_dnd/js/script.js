var draggable;
var droptarget;

function init() {

var check = document.createElement("div");
check.setAttribute("dropzone" , "move s:text/plain");
console.log(check.dropzone);

	draggable = document.getElementById( "draggable" );
	droptarget = document.getElementById( "droptarget" );
	
	draggable.ondragstart = dragStartHandler;
	draggable.ondrag = dragHandler;
	draggable.ondragend = dragEndHandler;
	
	droptarget.ondragenter = dragEnterHandler;
	droptarget.ondragover = dragOverHandler;
	droptarget.ondragleave = dragLeaveHandler;
	droptarget.ondrop = dropHandler;
}

function dragStartHandler(e) {
	console.log("dragstart");
	e.dataTransfer.setData("text/plain" , "Payload Landed" );
}

function dragHandler(e) {
	//console.log("drag");
}

function dragEndHandler(e) {
          console.log("dragend");
          droptarget.className = null
}


function dragEnterHandler(e) {
	console.log("dragenter");
}

function dragOverHandler(e) {
          console.log("dragover");
          droptarget.className = "over";
          if (e.preventDefault) e.preventDefault();
          return false;
}


function dragLeaveHandler(e) {
          console.log("dragleave");
          droptarget.className = null
}


function dropHandler(e) {
          console.log("drop");
          droptarget.innerHTML = e.dataTransfer.getData("text/plain");
          if (e.preventDefault) e.preventDefault();
          return false
}


window.onload = init;


/*
function cancel(e){
	if (e.preventDefault) e.preventDefault();
	return false;
}
*/