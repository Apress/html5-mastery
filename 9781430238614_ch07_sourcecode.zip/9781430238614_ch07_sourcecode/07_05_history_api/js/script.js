// create global variables
var xmlhttp;
var prevbutton;
var nextbutton;
var message;
var messageID = 1;

// initialize variables and add event listening functions
function init() {
           prevbutton = document.getElementById("prevButton");
           nextbutton = document.getElementById("nextButton");
           message = document.getElementById("message");
           
           prevbutton.onmousedown = prevButtonDown;
           nextbutton.onmousedown = nextButtonDown;

           checkButtons();
          loadFile();
}
// disable previous or next button depending on whether first or last message is displaying 
function checkButtons() {
          if ( messageID == 1 ) prevbutton.disabled = true;
          else prevbutton.disabled = false;
          if ( messageID == 3 ) nextbutton.disabled = true;
          else nextbutton.disabled = false;
}
// decrement message ID when previous button is pressed
function prevButtonDown() {
          messageID--;
          if (messageID < 1) messageID = 1;

          var obj = { page: messageID };
          var title = "page"+messageID;
          var url = "#message"+messageID;
          window.history.pushState( obj , title , url );

          checkButtons();
          loadFile();
}
function nextButtonDown() {
          messageID++;
          if (messageID > 3) messageID = 3;

          var obj = { page: messageID };
          var title = "page"+messageID;
          var url = "#message"+messageID;
          window.history.pushState( obj , title , url );

          checkButtons();
          loadFile();
}

// load message files using AJAX
function loadFile() {
           // retrieve the hashtag from the URL using the location object
           var messageHash = window.location.hash; 
           if (messageHash == "") messageHash = "#message1";
           var file = messageHash.substr(1)+".txt";     // strip out the "#" from the hashtag

           xmlhttp = new XMLHttpRequest();
           xmlhttp.onreadystatechange = responseReady;
           xmlhttp.open("GET",file,false);
           xmlhttp.send();
}

// add AJAX loaded content to paragraph on the page
function responseReady() {
          message.innerHTML=xmlhttp.responseText;
}
window.onload = init;
window.onpopstate = init;
