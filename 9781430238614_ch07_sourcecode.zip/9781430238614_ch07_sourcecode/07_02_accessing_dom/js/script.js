// init function runs when page has fully loaded
function init() {
	window.name = "MAIN";    // sets the name of the window
	window.alert("The name of this window is set to: " + window.name); // shows the name of the window
}

window.onload = init;
