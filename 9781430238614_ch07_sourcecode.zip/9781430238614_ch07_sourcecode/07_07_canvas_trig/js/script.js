// declare the global variables
var canvas;
var context;
var centerX;
var centerY;
var degrees = 0;
var radius = 1;

function init() {
          canvas = document.getElementById( "canvas" );
          context = canvas.getContext("2d");
          centerX = canvas.width/2;
          centerY = canvas.height/2;
          // move to the center of the canvas
          context.moveTo( centerX , centerY );
          // loop two thousand times, drawing a line out further and further from the center
          for (var i=0; i<2000;i++) {
                    degrees += 1;
                    radius += 0.02;
                    context.lineTo( 
                                centerX+Math.cos(degrees*Math.PI/180)*radius , 
                                centerY+Math.sin(degrees*Math.PI/180)*radius 
                                );
          }
          context.stroke();
}
window.onload = init;    
