// declare global variables
var canvas;                      // reference to canvas element on page
var context;                     // reference to canvas context
var cwidth;                      // reference to canvas width
var cheight;                     // reference to canvas height
var lastX = 0;                   // variable to hold an x coordinate value
var lastY = 0;                   // variable to hold an x coordinate value    

// initialize the variables and add event handler
function init() {
           canvas = document.getElementById( "canvas" );
           context = canvas.getContext("2d");
           cwidth = canvas.width;
           cheight = canvas.height;
           context.strokeStyle = "#000000";
           context.strokeRect(0,0,cwidth,cheight);

           canvas.onmousemove = draw;          // call the draw function when the cursor moves over the canvas
}
// draw on the canvas
function draw(e) {
           // update the saved x, y coordinates to the position of the cursor if it is first entering the canvas
           if (lastX == 0) lastX = e.pageX - canvas.offsetLeft; 
           if (lastY == 0) lastY = e.pageY - canvas.offsetTop;
           // begin a new line and move to the last saved x, y coordinates
           context.beginPath();
           context.moveTo(lastX, lastY);
           // set the saved x, y coordinates to the position of the mouse cursor
           lastX = e.pageX - canvas.offsetLeft;
           lastY = e.pageY - canvas.offsetTop;

           // draw a line
           context.lineTo(lastX, lastY);
           context.closePath();
           context.stroke();
}

window.onload = init;

