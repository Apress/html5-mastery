<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<p>Form results:</p>
	<p>
	<?php
	/* this file needs to be run on a server that can handle PHP */
	if (isset($_REQUEST["name"]) && isset($_REQUEST["name"])){
		 echo "Name: " . $_REQUEST["name"] . "<br />";
		 echo "Age: " . $_REQUEST["age"];
	}
	?>
	</p>
</body>
</html>